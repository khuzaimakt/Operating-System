#include <iostream>
#include <sys/wait.h>
#include <unistd.h>
#include <cstring>
#include <stdlib.h>
#include <fcntl.h>
#include<pthread.h>
#include<string.h>
#include<unistd.h>
#include<semaphore.h>
#include <cstdio>

using namespace std;



void *a(void *);
void *b(void *);
void *c(void *);

int counter=3;
sem_t s1;
sem_t s2;
sem_t s3;
pthread_t t[5];




void *a(void*)
{
	sem_wait(&s1);
	counter--;
	cout<<"a";
	if(counter==0)
	{
	 sem_post(&s3);
	}
	
	else
	{
	 sem_post(&s1);
	 
	}
 pthread_exit(NULL);
} 


void *b(void*)
{

  sem_wait(&s2);
  cout<<"b";
  pthread_exit(NULL);
}


void *c(void*)
{

 sem_wait(&s3);
 cout<<"c";
 sem_post(&s2);
 pthread_exit(NULL);

}


int main()
{

 sem_init(&s1,0,1);
 sem_init(&s2,0,0);
 sem_init(&s3,0,0);
 
 pthread_create(&t[0],NULL,&a,NULL);
 pthread_create(&t[1],NULL,&a,NULL);
 pthread_create(&t[2],NULL,&a,NULL);
 pthread_create(&t[3],NULL,&c,NULL);
 pthread_create(&t[4],NULL,&b,NULL);
 
 pthread_join(t[0],NULL);
 pthread_join(t[1],NULL);
 pthread_join(t[2],NULL);
 pthread_join(t[3],NULL);
 pthread_join(t[4],NULL);



 return 0;
}

 
