#include<semaphore.h>
#include<stdio.h>
#include<pthread.h>
# include<iostream>
using namespace std;


void *bowler(void* );
void *batsmen(void* );

sem_t bow;
sem_t bat;

sem_t mutex;
pthread_t bo[4];
	pthread_t bt[4];

void* bowler(void* i){
 sem_wait(&mutex);
 int value;
 sem_getvalue(&bow,&value);
 
 if(value==1)
 {
  cout<<"Bowler has arrived"<<endl;
  sem_wait(&bow);
  
  int n;
  sem_getvalue(&bat,&n);
  
  if(n==0)
  {
   
   cout<<"Batsmen and Bowler are practicing"<<endl;
   sem_post(&bow);
   sem_post(&bat);
   
   sem_post(&mutex);
   cout<<"Batsmen and bowler have practiced and left"<<endl;
  }
 
 else
 {
  
 
  sem_post(&mutex);
 }
 
 }
 
 else
 {
  
  cout<<"Already a bowler is practising"<<endl;
  sem_post(&mutex);
 
 }

}

void* batsmen(void* i){
sem_wait(&mutex);
 int value;
 sem_getvalue(&bat,&value);
 
 
 if(value==1)
 {
  cout<<"Batsmen has arrived"<<endl;
  sem_wait(&bat);
  int n;
  sem_getvalue(&bow,&n);
 
  if(n==0)
  {
   
   cout<<"Batsmen and Bowler are practicing"<<endl;
   sem_post(&bow);
   sem_post(&bat);
   
   sem_post(&mutex);
   cout<<"Batsmen and bowler have practiced and left"<<endl;
  }
 
 else
 {
  
  
  sem_post(&mutex);
 }
 
 }
 
 else
 {
  cout<<"Already a batsmen is practising"<<endl;
  sem_post(&mutex);
 }

}


int main()
{

	
	sem_init(&bow,0,1);
	sem_init(&bat,0,1);
	
	sem_init(&mutex,0,1);
	
	
	pthread_create(&bo[0],NULL,bowler,(void*) 0);
	pthread_create(&bt[0],NULL,batsmen,(void*) 0);

	
		
	
	
	pthread_join(bo[0],NULL);
	
	pthread_join(bt[0],NULL);
	
	
	
	
	
	
	
	
	
	

return 0;
}




