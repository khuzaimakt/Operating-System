#include <iostream>
#include <sys/wait.h>
#include <unistd.h>
#include <cstring>
#include <stdlib.h>
#include <fcntl.h>
#include<pthread.h>
#include<string.h>
#include<unistd.h>
#include<readline/readline.h> 

using namespace std;
struct data{

int* a;
int size;
int avg;
int max;
int min;
};



void *thread_avg(void * args);
void *thread_max(void* args);
void *thread_min(void* args);

int main()
{
 pthread_t t1;
 pthread_t t2;
 pthread_t t3;
 char* parse[100];
 struct data d;
 
 int value=0;
 char* input;
 input=readline("\n>>> ");
 
 for (int i = 0; i < 100; i++)
         {
         	
        	 parse[i]= strsep(&input, " ");
  		
        	if (parse[i] == NULL)
            		break;
        	if (strlen(parse[i]) == 0)
            		i--;
           
           d.size=i; 		
    	}
   
    	
    	
  d.a=new int[d.size];
 for(int i=0;i<=d.size;i++)
 {
 
  d.a[i]=atoi(parse[i]);
  
 }
    	
   
 pthread_create(&t1, NULL, thread_avg, (void *) &d);
 pthread_create(&t2, NULL, thread_max, (void *) &d);
 pthread_create(&t3, NULL, thread_min, (void *) &d);
 pthread_join(t1,NULL);
 
 cout<<"Average: ";
 cout<< d.avg<<endl;
 
 
 pthread_join(t2,NULL);
 
 cout<<"Max: ";
 cout<< d.max<<endl;
 
pthread_join(t3,NULL);
 
 cout<<"Min: ";
 cout<< d.min<<endl;
 

return 0;
}

void* thread_avg(void* args)
{
 int sum=0;
 struct data *td;
 td= (struct data*) args;
 
 for(int i=0;i<=td->size;i++)
 {
 
  sum+=td->a[i];
 
 }
 
 td->avg=sum/(td->size+1);
 
}


void* thread_max(void* args)
{
 int max;
 struct data *td;
 td= (struct data*) args;
 max=td->a[0];
 for(int i=1;i<=td->size;i++)
 {
 
  if(td->a[i]>max)
  max=td->a[i];
 
 }
 
 td->max=max;
 
}

void* thread_min(void* args)
{
 int min;
 struct data *td;
 td= (struct data*) args;
 min=td->a[0];
 for(int i=1;i<=td->size;i++)
 {
 
  if(td->a[i]<min)
  min=td->a[i];
 
 }
 
 td->min=min;
 
}


