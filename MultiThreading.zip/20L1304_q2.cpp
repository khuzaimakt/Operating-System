#include <iostream>
#include <sys/wait.h>
#include <unistd.h>
#include <cstring>
#include <stdlib.h>
#include <fcntl.h>
#include<pthread.h>
#include<string.h>
#include<unistd.h>
#include<readline/readline.h> 

using namespace std;

void* thread_prime(void* args);
int main()
{
pthread_t t1;
char* input;
input=readline("\n>>> ");

int value;
value=atoi(input);
pthread_create(&t1,NULL,thread_prime,(void *) &value);
pthread_join(t1,NULL);



 
return 0;

}

void* thread_prime(void* args)
{

 int  value;
 value=*((int* ) args);
 cout<<"Prime Numbers: "<< endl;
 bool is_prime;
 for(int i=0;i<=value;i++){
  is_prime=true;
 if (i == 0 || i == 1) {
    is_prime = false;
  }
 
 else{
 
  for (int j = 2; j <= i/2; ++j) {
    if (i % j == 0) {
    is_prime=false;
      break;
    }
    
    
  
 }
 }
 if(is_prime==true)
  cout<<i<<" ";

}

}
