#include <iostream>
#include <sys/wait.h>
#include <unistd.h>
#include <cstring>
#include <stdlib.h>
#include <fcntl.h>
#include<pthread.h>
#include<string.h>
#include<unistd.h>
#include<readline/readline.h> 


using namespace std;

struct data{
int *a;

int n;
};
void* thread_fib(void* args);
void* thread_print(void* args);
int main()
{
pthread_t t1;
pthread_t t2;
char* input;
input=readline("\n>>> ");

struct data d;
d.n=atoi(input);
d.a=new int[d.n];
pthread_create(&t1,NULL,thread_fib,(void *) &d);
pthread_create(&t2,NULL,thread_print,(void *) &d);

pthread_join(t1,NULL);


pthread_join(t2,NULL);
 
return 0;

}

void* thread_fib(void* args)
{

 struct data *td;
 td=(struct data* ) args;
 
 td->a[0]=0;
 td->a[1]=1;
 for(int i=2;i<=td->n;i++)
 {
 	td->a[i]=td->a[i-1]+ td->a[i-2];
 }
 
  

}

void* thread_print(void* args)
{
cout<<"Fibonnaci Series: ";
struct data *td;
 td=(struct data* ) args;
 
 for(int i=0;i<td->n;i++){
 cout<<td->a[i]<<" ";
}
cout<<endl;
}

