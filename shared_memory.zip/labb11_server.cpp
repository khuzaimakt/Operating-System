#include <iostream>
#include <sys/wait.h>
#include <unistd.h>
#include <cstring>
#include <stdlib.h>
#include <fcntl.h>
#include<pthread.h>
#include<string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include<unistd.h>
#include<semaphore.h>
#include <cstdio>
using namespace std;


int main(int argc,char* argv[])
{
int arr[100];
int c=0;
int sum=0;
 key_t key=ftok("shmfile",65);
 int shmid=shmget(key,1024,0666 | IPC_CREAT);
char*buffer= (char*) shmat(shmid,(void*) 0,0);
for(int i=0;buffer[i]!='\0';i++)
{
    arr[i]=atoi(buffer[i]);
    c++;
}
for(int i=0;i<=c;i++)
{
    sum+=arr[i];
}
cout<<"Sum of integers is: ";
cout<<sum<<endl;
cout<<"Average of integers is: "<<
cout<<sum/c<<endl;
shmdt(buffer);
shmctl(shmid,IPC_RMID,NULL);
return 0;
}
