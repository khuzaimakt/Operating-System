#include <iostream>
#include <sys/wait.h>
#include <unistd.h>
#include <cstring>
#include <stdlib.h>
#include <fcntl.h>
#include<pthread.h>
#include<string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include<unistd.h>
#include<semaphore.h>
#include <cstdio>
using namespace std;
int main(int argc,char* argv[])
{
int file=open(argv[1],O_RDONLY);
 key_t key=ftok("shmfile",65);
 int shmid=shmget(key,1024,0666 | IPC_CREAT);
char*buffer= (char*) shmat(shmid,(void*) 0,0);
 read(file,buffer,100);
printf("Data written in memory: %s\n",buffer);
shmdt(buffer);
return 0;
}
